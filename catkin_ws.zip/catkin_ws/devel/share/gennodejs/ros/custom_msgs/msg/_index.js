
"use strict";

let vecOfDoubles = require('./vecOfDoubles.js');

module.exports = {
  vecOfDoubles: vecOfDoubles,
};
