
"use strict";

let ExampleMessage = require('./ExampleMessage.js');
let vecOfDoubles = require('./vecOfDoubles.js');

module.exports = {
  ExampleMessage: ExampleMessage,
  vecOfDoubles: vecOfDoubles,
};
