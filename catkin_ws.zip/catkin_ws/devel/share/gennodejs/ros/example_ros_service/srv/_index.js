
"use strict";

let ExampleServiceMsg = require('./ExampleServiceMsg.js')

module.exports = {
  ExampleServiceMsg: ExampleServiceMsg,
};
